export interface topcard {
    bgcolor: string,
    icon: string,
    title: string,
    subtitle: string
}

export const topcards: topcard[] = [

    {
        bgcolor: 'success',
        icon: 'bi bi-wallet',
        title: 'Rs2100',
        subtitle: 'Yearly Earning'
    },
    {
        bgcolor: 'danger',
        icon: 'bi bi-coin',
        title: '4560',
        subtitle: 'Return Book'
    },
    {
        bgcolor: 'warning',
        icon: 'bi bi-basket3',
        title: '4565',
        subtitle: 'Assign Book'
    },
    {
        bgcolor: 'info',
        icon: 'bi bi-bag',
        title: '21097',
        subtitle: 'Total Book'
    },

] 