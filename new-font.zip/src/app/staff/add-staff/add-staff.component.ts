
  import { Component, OnInit } from '@angular/core';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';
  import { Router } from '@angular/router';
  import { StaffService } from '.././../provider/staff.service';

  @Component({
    selector: 'app-add-staff',
    templateUrl: './add-staff.component.html',
    styleUrls: ['./add-staff.component.scss']
  })
  export class AddStaffComponent implements OnInit {
       staffForm!: FormGroup;
    constructor(public router: Router, public formBuilder: FormBuilder,
      private staffService: StaffService) { }
  
    ngOnInit(): void {
      this.addFromBinding();
    }
  
    addFromBinding() {
      this.staffForm = this.formBuilder.group({
        staffName: ['', Validators.required],
        designation: ['', Validators.required],
        email: ['', Validators.required],
        phone: ['', Validators.required],
        adress: ['', Validators.required],
      })
    }
    get staffName() { return this.staffForm.get('staffName'); }
    get designation() { return this.staffForm.get('designation'); }
    get email() { return this.staffForm.get('email'); }
    get phone() { return this.staffForm.get('phone'); }
    get adress() { return this.staffForm.get('adress'); }
  
    submitstaff() {
      let payloadData = {
        staffName: this.staffName?.value,
        designation: this.designation?.value,
        email: this.email?.value,
        createdBy: "Garima",
        phone: this.phone?.value,
        adress:this.adress?.value,
        password:123457890
      }
      console.log("request", payloadData)
      this.staffService.addstaff(payloadData).subscribe((res: any) => {
        console.log(res)
        this.goback();
      }, (err) => {
        console.log(err);
      });
    }
    goback() {
      this.router.navigate(['/staff/list-staff'])
    }
  }
  