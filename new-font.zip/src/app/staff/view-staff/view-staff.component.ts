import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-staff',
  templateUrl: './view-staff.component.html',
  styleUrls: ['./view-staff.component.scss']
})
export class ViewStaffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
