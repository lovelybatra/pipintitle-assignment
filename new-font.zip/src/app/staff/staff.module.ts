import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StaffRoutingModule } from './staff-routing.module';
import { StaffComponent } from './staff.component';
import { AddStaffComponent } from './add-staff/add-staff.component';
import { EditStaffComponent } from './edit-staff/edit-staff.component';
import { ViewStaffComponent } from './view-staff/view-staff.component';
import { ListStaffComponent } from './list-staff/list-staff.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [
    StaffComponent,
    AddStaffComponent,
    EditStaffComponent,
    ViewStaffComponent,
    ListStaffComponent
  ],
  imports: [
    CommonModule,
    StaffRoutingModule,FormsModule,
    ReactiveFormsModule,
    NgbModule,
  ]
})
export class StaffModule { }
