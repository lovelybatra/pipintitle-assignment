
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StaffService } from '.././../provider/staff.service';

@Component({
  selector: 'app-edit-staff',
  templateUrl: './edit-staff.component.html',
  styleUrls: ['./edit-staff.component.scss']
})
export class EditStaffComponent implements OnInit {



  staffForm!: FormGroup;
  staffDataStore: any;
  constructor(public router: Router, public formBuilder: FormBuilder,
    private staffService: StaffService) {
    this.staffDataStore = this.staffService.staffData;
    if (this.staffDataStore['_id'] == 0 || this.staffDataStore['_id'] == '') {
      this.router.navigate(['/staff/list-staff'])
    }
  }

  ngOnInit(): void {
    this.addFromBinding();
    this.frompatchBinding();
  }

  addFromBinding() {
    this.staffForm = this.formBuilder.group({
      staffName: ['', Validators.required],
      designation: ['1', Validators.required],
      email: ['', Validators.required],
      phone: ['', Validators.required],
      adress: ['', Validators.required],
    })
  }
  frompatchBinding() {
    this.staffForm = this.formBuilder.group({
      staffName: this.staffDataStore.staffName,
      designation: this.staffDataStore.designation,
      email: this.staffDataStore.email,
      phone: this.staffDataStore.phone,
      adress: this.staffDataStore.adress
    })
  }
  get staffName() { return this.staffForm.get('staffName'); }
  get designation() { return this.staffForm.get('designation'); }
  get email() { return this.staffForm.get('email'); }
  get phone() { return this.staffForm.get('phone'); }
  get adress() { return this.staffForm.get('adress'); }




  submitstaff() {
    let payloadData = {
      staffName: this.staffName?.value,
      designation: this.designation?.value,
      email: this.email?.value,
      phone: this.phone?.value,
      adress: this.adress?.value,
      password: 12345789
    }
    console.log("request", payloadData)
    this.staffService.patchstaff(this.staffDataStore._id, payloadData).subscribe((res: any) => {
      console.log(res)
      this.goback();
    }, (err) => {
      console.log(err);
    });
  }
  goback() {
    this.router.navigate(['/staff/list-staff'])
  }
}
