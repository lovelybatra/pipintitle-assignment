

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StaffService } from '.././../provider/staff.service';


@Component({
  selector: 'app-list-staff',
  templateUrl: './list-staff.component.html',
  styleUrls: ['./list-staff.component.scss']
})
export class ListStaffComponent implements OnInit {
    rows: any;
  constructor(
    private router: Router,
    private staffService: StaffService
  ) {
    this.rows = [];

  }
  ngOnInit(): void {
    this.rows = [];

    this.getstaff()
  }
  getstaff() {
    this.staffService.getstaff().subscribe(
      (res: any) => {
        this.rows = res;

      },
      (err: any) => {
        console.log(err)
      }
    );
  }
  addNavigate() {
    this.router.navigate(['/staff/add-staff'])
  }
  deletestaff(id: any) {
    confirm("Your want delete this staff");
    this.staffService.deletestaff(id).subscribe(
      (res: any) => {
        this.getstaff()
      },
      (err: any) => {
        console.log(err)
      }
    );
  }

  editHandle(row: any) {
    this.staffService.staffData = { ...row }
    this.router.navigate(['/staff/edit-staff'])

  }
}
