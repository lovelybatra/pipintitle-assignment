import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReturnComponent } from './return/return.component';
import { IssuedComponent } from './issued/issued.component';

const routes: Routes = [
  {
    path: 'return',
    component: ReturnComponent,},
    {
    path: 'assign',
    component: IssuedComponent,
   
  } 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BookIssuedRoutingModule { }
