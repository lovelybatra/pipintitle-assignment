

  import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {BookService} from '.././../provider/book.service';
import {StudentService} from '.././../provider/student.service';

@Component({
  selector: 'app-return',
  templateUrl: './return.component.html',
  styleUrls: ['./return.component.scss']
})
export class ReturnComponent implements OnInit {
    bookArry: any;
  studentData: any;
  issueFrom!: FormGroup;
  studentIdValue:any;
  bookIdValue:any;
  rows: any=[];
  constructor(  private router:Router,public formBuilder: FormBuilder,
    private BookService:BookService,  private studentService:StudentService
  
  ) { 
    this.bookArry=[];
    this.studentData=[]
  }

  ngOnInit(): void {
   
    this.rows=[];
    
    this.getAssignbookByStatus('Return')
 
    }
   
    getAssignbookByStatus(status:any){
      console.log("haha",status)
      this.BookService.getAssignbookByStatus(status).subscribe(
        (res: any) => {
          this.rows = res;
        
        },
        (err) => {
          console.log(err)
        }
      );
    }
  
  getstudent(){
    this.studentService.getstudent().subscribe(
      (res: any) => {
        this.studentData = res;
      
      },
      (err:any) => {
        console.log(err)
      }
    );
  }
  getBook(){
    this.BookService.getBook().subscribe(
      (res: any) => {
        this.bookArry = res;
      },
      (err) => {
        console.log(err)
      }
    );
  }
  addFromBinding() {
    this.issueFrom = this.formBuilder.group({
      studentId: ['', Validators.required],
      bookId: ['', Validators.required],
      dueDate: ['', Validators.required],
    })
  }
  get studentId() { return this.issueFrom.get('studentId'); }
  get bookId() { return this.issueFrom.get('bookId'); }
  get dueDate() { return this.issueFrom.get('dueDate'); }
  
  deletebook(id: any) {
    confirm("Your want delete this book");
    this.BookService.deleteassignbook(id).subscribe(
      (res: any) => {
        this.getAssignbookByStatus('Return')
      },
      (err) => {
        console.log(err)
      }
    );
  }


  submitBook() {
    let payloadData = {
      studentId: this.studentId?.value,
      bookId: this.bookId?.value,
      dueDate:this.dueDate?.value
    }
    console.log("request", payloadData)
    this.BookService.assignbook(payloadData).subscribe((res: any) => {
      console.log(res)
      this.goback();
    }, (err) => {
      console.log(err);
    });
  }
  goback() {
    this.router.navigate(['/book-directory/list-book-directory'])
  }

}
