import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BookIssuedRoutingModule } from './book-issued-routing.module';
import { ReturnComponent } from './return/return.component';
import { IssuedComponent } from './issued/issued.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    ReturnComponent,
    IssuedComponent
  ],
  imports: [
    CommonModule,
    BookIssuedRoutingModule,NgSelectModule,FormsModule,
    ReactiveFormsModule,
    NgbModule
  ]
})
export class BookIssuedModule { }
