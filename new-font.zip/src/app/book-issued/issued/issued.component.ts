import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { BookService } from '.././../provider/book.service';
import { StudentService } from '.././../provider/student.service';
import { ReturnComponent } from '../return/return.component';

@Component({
  selector: 'app-issued',
  templateUrl: './issued.component.html',
  styleUrls: ['./issued.component.scss']
})
export class IssuedComponent implements OnInit {
  bookArry: any;
  studentData: any;
  issueFrom!: FormGroup;
  studentIdValue: any;
  bookIdValue: any;
  bookNameValue: any;
  studentNmaeValue: any;
  rows: any;
  showingADdForm: boolean = false;
  constructor(private router: Router, public formBuilder: FormBuilder,
    private BookService: BookService, private studentService: StudentService,
    private modalService: NgbModal,
  ) {
    this.bookArry = [];
    this.studentData = []
  }

  ngOnInit(): void {

    this.rows = [];
     this.getAssignbookByStatus('Assign')
  }


  getAssignbookByStatus(status: any) {
    console.log("haha", status)
    this.BookService.getAssignbookByStatus(status).subscribe(
      (res: any) => {
        this.rows = res;

      },
      (err) => {
        console.log(err)
      }
    );
  }
  getstudent() {
    this.studentService.getstudent().subscribe(
      (res: any) => {
        this.studentData = res;

      },
      (err: any) => {
        console.log(err)
      }
    );
  }
  getBook() {
    this.BookService.getBook().subscribe(
      (res: any) => {
        this.bookArry = res;
      },
      (err) => {
        console.log(err)
      }
    );
  }
  getBookValue(id: any) {
    this.bookArry.forEach((element: any) => {
      if (element._id == id) {
        this.bookNameValue = element.bookName
      }
    });

  }
  getStudentValue(id: any) {
    this.studentData.forEach((element: any) => {
      if (element._id == id) {
        this.studentNmaeValue = element.name
      }
    });
  }
  addFromBinding() {
    this.issueFrom = this.formBuilder.group({
      studentId: ['', Validators.required],
      bookId: ['', Validators.required],
      dueDate: ['', Validators.required],
    })
  }
  get studentId() { return this.issueFrom.get('studentId'); }
  get bookId() { return this.issueFrom.get('bookId'); }
  get dueDate() { return this.issueFrom.get('dueDate'); }


  submitBook() {
    let payloadData = {
      studentId: this.studentId?.value,
      bookId: this.bookId?.value,
      dueDate: this.dueDate?.value,
      studentName: this.studentNmaeValue,
      bookName: this.bookNameValue,
      createdBy: "Garima",
      status: "Assign"
    }
    console.log("request", payloadData)
    this.BookService.assignbook(payloadData).subscribe((res: any) => {
      console.log(res)
      this.goback();
    }, (err) => {
      console.log(err);
    });
  }
  goback() {
    this.showingADdForm = false;
    this.getAssignbookByStatus('Assign')
  }
  addNavigate() {
    this.showingADdForm = true;
    this.getBook();
    this.getstudent();
    this.addFromBinding();
  }
  deletebook(id: any) {
    confirm("Your want delete this book");
    this.BookService.deleteassignbook(id).subscribe(
      (res: any) => {
        this.getAssignbookByStatus('Assign')
      },
      (err) => {
        console.log(err)
      }
    );
  }
  returnBook(row: any, content: any) {
    this.modalService.open(content, {
      ariaLabelledBy: 'modal-basic-title', size: 'xl', centered: true, backdrop: 'static',
      keyboard: false,
    })
      .result.then((result) => {
        this.updateStaus(row);
      }, (reason) => {

      });
  }
  updateStaus(row: any) {
    let payloadData = {
      status: "Return",
    }
    console.log("request", payloadData)
    this.BookService.patchAssignbook(row._id, payloadData).subscribe((res: any) => {
      console.log(res)
      this.goback();
    }, (err) => {
      console.log(err);
    });
  }
}
