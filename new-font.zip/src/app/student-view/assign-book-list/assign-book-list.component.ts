import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assign-book-list',
  templateUrl: './assign-book-list.component.html',
  styleUrls: ['./assign-book-list.component.scss']
})
export class AssignBookListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
