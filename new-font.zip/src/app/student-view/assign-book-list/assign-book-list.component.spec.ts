import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignBookListComponent } from './assign-book-list.component';

describe('AssignBookListComponent', () => {
  let component: AssignBookListComponent;
  let fixture: ComponentFixture<AssignBookListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssignBookListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignBookListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
