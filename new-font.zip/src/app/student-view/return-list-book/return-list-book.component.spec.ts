import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReturnListBookComponent } from './return-list-book.component';

describe('ReturnListBookComponent', () => {
  let component: ReturnListBookComponent;
  let fixture: ComponentFixture<ReturnListBookComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReturnListBookComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturnListBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
