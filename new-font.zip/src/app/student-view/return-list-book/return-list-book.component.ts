import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-list-book',
  templateUrl: './return-list-book.component.html',
  styleUrls: ['./return-list-book.component.scss']
})
export class ReturnListBookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
