import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StudentViewRoutingModule } from './student-view-routing.module';
import { StudentLoginComponent } from './student-login/student-login.component';
import { AssignBookListComponent } from './assign-book-list/assign-book-list.component';
import { ReturnListBookComponent } from './return-list-book/return-list-book.component';


@NgModule({
  declarations: [
    StudentLoginComponent,
    AssignBookListComponent,
    ReturnListBookComponent
  ],
  imports: [
    CommonModule,
    StudentViewRoutingModule
  ]
})
export class StudentViewModule { }
