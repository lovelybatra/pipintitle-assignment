import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StudentLoginComponent } from './student-login/student-login.component';
import { AssignBookListComponent } from './assign-book-list/assign-book-list.component';
import { ReturnListBookComponent } from './return-list-book/return-list-book.component';


const routes: Routes = [
  {
    path: '',
    component: StudentLoginComponent,
  
  } , {
    path: 'Assign-list',
    component: AssignBookListComponent,
  
  } ,
  {
    path: 'return-list',
    component: ReturnListBookComponent,
  
  } 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentViewRoutingModule { }
