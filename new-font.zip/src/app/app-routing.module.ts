import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FullComponent } from './layouts/full/full.component';
import { AuthGuard } from './provider/guard/auth.guard';

export const Approutes: Routes = [
  { path: 'auth', loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule) },
 
  {
    path: '',
    component: FullComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule)
      },
      {
        path: 'book-directory',
        loadChildren: () => import('./book-directory/book-directory.module').then(m => m.BookDirectoryModule)
      },
      {
        path: 'book-issued',
        loadChildren: () => import('./book-issued/book-issued.module').then(m => m.BookIssuedModule)
      },
      {
        path: 'staff',
        loadChildren: () => import('./staff/staff.module').then(m => m.StaffModule)
      },
      {
        path: 'student',
        loadChildren: () => import('./student/student.module').then(m => m.StudentModule)
      },
      { path: '', redirectTo: 'book-directory', pathMatch: 'full' }, 
    ]
  },
  {
    path: '**',
    redirectTo: '/starter'
  }
];
