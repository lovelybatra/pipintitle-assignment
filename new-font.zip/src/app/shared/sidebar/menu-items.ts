import { RouteInfo } from './sidebar.metadata';

export const ROUTES: RouteInfo[] = [
 
  {
    path: '/dashboard',
    title: 'Dashboard',
    icon: 'bi bi-speedometer2',
    class: '',
    extralink: false,
    submenu: []
  },
  {
    path: '/book-directory',
    title: 'Book directory',
    icon: 'bi bi-book',
    class: '',
    extralink: false,
    submenu: []
  },
 
  {
    path: '/staff',
    title: 'Staff ',
    icon: 'bi bi-people',
    class: '',
    extralink: false,
    submenu: []
  },
  {
    path: '/student',
    title: 'Student',
    icon: 'bi bi-person',
    class: '',
    extralink: false,
    submenu: []
  },
  {
    path: '/book-issued/assign',
    title: 'Assign',
    icon: 'bi bi-ui-checks-grid',
    class: '',
    extralink: false,
    submenu: []
  },
  {
    path: '/book-issued/return',
    title: 'Return',
    icon: 'bi bi-ui-checks',
    class: '',
    extralink: false,
    submenu: []
  },

];
