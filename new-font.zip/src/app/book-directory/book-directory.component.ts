import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-directory',
  templateUrl: './book-directory.component.html',
  styleUrls: ['./book-directory.component.scss']
})
export class BookDirectoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
