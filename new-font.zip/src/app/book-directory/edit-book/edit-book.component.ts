
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BookService } from '.././../provider/book.service';

@Component({
  selector: 'app-edit-book',
  templateUrl: './edit-book.component.html',
  styleUrls: ['./edit-book.component.scss']
})
export class EditBookComponent implements OnInit {
  bookForm!: FormGroup;
  bookDataStore: any;
  constructor(public formBuilder: FormBuilder, public router: Router,
    private BookService: BookService) {
    this.bookDataStore = this.BookService.bookData;
    if (this.bookDataStore['_id'] == 0 || this.bookDataStore['_id'] == '') {
      this.router.navigate(['/book-directory/list-book-directory'])
    }
  }

  ngOnInit(): void {
    this.addFromBinding();
    this.patchVinding();
  }

  addFromBinding() {
    this.bookForm = this.formBuilder.group({
      bookName: ['', Validators.required],
      bookAuthor: ['', Validators.required],
      price: ['1', Validators.required],
      totalQty: ['1', Validators.required],
    })
  }
  patchVinding() {
    this.bookForm.patchValue({
      bookName: this.bookDataStore.bookName,
      bookAuthor: this.bookDataStore.bookAuthor,
      price: this.bookDataStore.price,
      totalQty: this.bookDataStore.totalQty,
    })
  }


  get bookName() { return this.bookForm.get('bookName'); }
  get bookAuthor() { return this.bookForm.get('bookAuthor'); }
  get price() { return this.bookForm.get('price'); }
  get totalQty() { return this.bookForm.get('totalQty'); }




  submitBook() {

    let payloadData = {
      bookName: this.bookName?.value,
      bookAuthor: this.bookAuthor?.value,
      price: this.price?.value,
      createdBy: "Garima",
      totalQty: this.totalQty?.value
    }
    console.log("request", payloadData)
    this.BookService.patchBook(this.bookDataStore._id, payloadData).subscribe((res: any) => {
      console.log(res)
      this.goback();
    }, (err) => {
      console.log(err);
    });
  }
  goback() {
    this.router.navigate(['/book-directory/list-book-directory'])
  }
}
