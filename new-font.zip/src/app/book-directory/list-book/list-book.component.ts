import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {BookService} from '.././../provider/book.service';

@Component({
  selector: 'app-list-book',
  templateUrl: './list-book.component.html',
  styleUrls: ['./list-book.component.scss']
})
export class ListBookComponent implements OnInit {
  rows: any;
  constructor(
    private router:Router,
    private BookService:BookService
  ) { 
    this.rows=[];
    
  }
  ngOnInit(): void {
    this.rows=[];
  this.getBook()
  }
  getBook(){
    this.BookService.getBook().subscribe(
      (res: any) => {
        this.rows = res;
      
      },
      (err) => {
        console.log(err)
      }
    );
  }
  addNavigate(){
    this.router.navigate(['/book-directory/add-book-directory'])
  }
  deletebook(id:any){
    confirm("Your want delete this book");
    this.BookService.deleteBook(id).subscribe(
      (res: any) => {
      this.getBook()
      },
      (err) => {
        console.log(err)
      }
    );
  }

  editHandle(row:any){
    this.BookService.bookData={...row}
    this.router.navigate(['/book-directory/edit-book-directory'])
 
  }
}