import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BookService } from '.././../provider/book.service';
@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.scss']
})
export class AddBookComponent implements OnInit {
  bookForm!: FormGroup;
  constructor(public router: Router, public formBuilder: FormBuilder,
    private BookService: BookService) { }

  ngOnInit(): void {
    this.addFromBinding();
  }

  addFromBinding() {
    this.bookForm = this.formBuilder.group({
      bookName: ['', Validators.required],
      bookAuthor: ['', Validators.required],
      price: ['1', Validators.required],
      totalQty: ['1', Validators.required],
    })
  }
  get bookName() { return this.bookForm.get('bookName'); }
  get bookAuthor() { return this.bookForm.get('bookAuthor'); }
  get price() { return this.bookForm.get('price'); }
  get totalQty() { return this.bookForm.get('totalQty'); }




  submitBook() {
    let payloadData = {
      bookName: this.bookName?.value,
      bookAuthor: this.bookAuthor?.value,
      price: this.price?.value,
      createdBy: "Garima",
      totalQty: this.totalQty?.value
    }
    console.log("request", payloadData)
    this.BookService.addBook(payloadData).subscribe((res: any) => {
      console.log(res)
      this.goback();
    }, (err) => {
      console.log(err);
    });
  }
  goback() {
    this.router.navigate(['/book-directory/list-book-directory'])
  }
}
