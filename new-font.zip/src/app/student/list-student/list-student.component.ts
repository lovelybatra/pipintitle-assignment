
  import { Component, OnInit } from '@angular/core';
  import { Router } from '@angular/router';
  import {StudentService} from '.././../provider/student.service';

  @Component({
    selector: 'app-list-student',
    templateUrl: './list-student.component.html',
    styleUrls: ['./list-student.component.scss']
  })
  export class ListStudentComponent implements OnInit {
    rows: any;
    constructor(
      private router:Router,
      private studentService:StudentService
    ) { 
  this.rows=[];
      
    }
    ngOnInit(): void {
      this.rows=[];
      
    this.getstudent()
    }
    getstudent(){
      this.studentService.getstudent().subscribe(
        (res: any) => {
          this.rows = res;
        
        },
        (err:any) => {
          console.log(err)
        }
      );
    }
    addNavigate(){
      this.router.navigate(['/student/add-student'])
    }
    deletestudent(id:any){
      confirm("Your want delete this student");
      this.studentService.deletestudent(id).subscribe(
        (res: any) => {
        this.getstudent()
        },
        (err:any) => {
          console.log(err)
        }
      );
    }
  
    editHandle(row:any){
      this.studentService.studentData={...row}
      this.router.navigate(['/student/edit-student'])
   
    }
  }
  