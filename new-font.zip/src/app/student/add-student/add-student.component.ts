
  import { Component, OnInit } from '@angular/core';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';
  import { Router } from '@angular/router';
  import { StudentService } from '.././../provider/student.service';
  @Component({
    selector: 'app-add-student',
    templateUrl: './add-student.component.html',
    styleUrls: ['./add-student.component.scss']
  })
  export class AddStudentComponent implements OnInit {
      studentForm!: FormGroup;
    constructor(public router: Router, public formBuilder: FormBuilder,
      private studentService: StudentService) { }
  
    ngOnInit(): void {
      this.addFromBinding();
    }
  
    addFromBinding() {
      this.studentForm = this.formBuilder.group({
        studentName: ['', Validators.required],
        studentClass: ['1', Validators.required],
        email: ['', Validators.required],
        phone: ['', Validators.required],
        adress: ['', Validators.required],
      })
    }
    get studentName() { return this.studentForm.get('studentName'); }
    get studentClass() { return this.studentForm.get('studentClass'); }
    get email() { return this.studentForm.get('email'); }
    get phone() { return this.studentForm.get('phone'); }
  
    get adress() { return this.studentForm.get('adress'); }
  
  
  
  
    submitstudent() {
      let payloadData = {
        name: this.studentName?.value,
        studentClass: this.studentClass?.value,
        email: this.email?.value,
        createdBy: "Garima",
        phone: this.phone?.value,
        adress:this.adress?.value,
        password:123457890
      }
      console.log("request", payloadData)
      this.studentService.addstudent(payloadData).subscribe((res: any) => {
        console.log(res)
        this.goback();
      }, (err) => {
        console.log(err);
      });
    }
    goback() {
      this.router.navigate(['/student/list-student'])
    }
  }
  