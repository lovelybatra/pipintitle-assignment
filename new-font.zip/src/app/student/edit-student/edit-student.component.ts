
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StudentService } from '.././../provider/student.service';
@Component({
  selector: 'app-edit-student',
  templateUrl: './edit-student.component.html',
  styleUrls: ['./edit-student.component.scss']
})
export class EditStudentComponent implements OnInit {

  studentForm!: FormGroup;
  studentDataStore: any;
  constructor(public router: Router, public formBuilder: FormBuilder,
    private studentService: StudentService) {
    this.studentDataStore = this.studentService.studentData;
    if (this.studentDataStore['_id'] == 0 || this.studentDataStore['_id'] == '') {
      this.router.navigate(['/student/list-student'])
    }
  }

  ngOnInit(): void {
    this.addFromBinding();
    this.frompatchBinding();
  }

  addFromBinding() {
    this.studentForm = this.formBuilder.group({
      studentName: ['', Validators.required],
      studentClass: ['1', Validators.required],
      email: ['', Validators.required],
      phone: ['', Validators.required],
      adress: ['', Validators.required],
    })
  }
  frompatchBinding() {
    this.studentForm = this.formBuilder.group({
      studentName:this.studentDataStore.name,
      studentClass:this.studentDataStore.studentClass,
      email:this.studentDataStore.email,
      phone:this.studentDataStore.phone,
      adress: this.studentDataStore.adress
    })
  }
  get studentName() { return this.studentForm.get('studentName'); }
  get studentClass() { return this.studentForm.get('studentClass'); }
  get email() { return this.studentForm.get('email'); }
  get phone() { return this.studentForm.get('phone'); }
  get adress() { return this.studentForm.get('adress'); }




  submitstudent() {
    let payloadData = {
      name: this.studentName?.value,
      studentClass: this.studentClass?.value,
      email: this.email?.value,
      phone: this.phone?.value,
      adress: this.adress?.value,
      password: 12345789
    }
    console.log("request", payloadData)
    this.studentService.patchstudent(this.studentDataStore._id,payloadData).subscribe((res: any) => {
      console.log(res)
      this.goback();
    }, (err) => {
      console.log(err);
    });
  }
  goback() {
    this.router.navigate(['/student/list-student'])
  }
}
