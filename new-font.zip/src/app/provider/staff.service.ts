import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StaffService {

  apiUrl:any;
  staffData:any;
  constructor(public http:HttpClient) { 
    this.apiUrl=environment.apiUrl;
  }

  addstaff(reqObj: any): Observable<any> {
    return this.http.post(this.apiUrl + 'staff', reqObj);
  }
  patchstaff(id: any, reqObj: any): Observable<any> {
    return this.http.patch(this.apiUrl + 'staff/' + id, reqObj);
  }

  deletestaff(id: any): Observable<any> {
    return this.http.delete(this.apiUrl + 'staff/' + id);
  }
  
  getstaff(): Observable<any> {
    return this.http.get(this.apiUrl + 'staff');
  }
}
