import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";

import { of } from "rxjs";
import { delay } from "rxjs/operators";
import { environment } from '../../environments/environment';
import { Observable, Subject } from 'rxjs';
@Injectable({
  providedIn: "root"
})
export class AuthService {
  //Only for demo purpose
  rItem = {};
  authenticated = true;
  private userSubject = new Subject<any>();
  token: any;
  constructor(
    private _route: Router,
    private _http: HttpClient,
   
  ) {
    
  }

 
  signout() {
    this.authenticated = false;
     localStorage.removeItem('isLoggedin');
    
    }
  login(requestData:any) {
    this.authenticated = true;
    console.log('login service -> login method', requestData);
    let url = environment.apiUrl + 'stafflogin';
    console.log('login servoce url', url);
    return this._http.post(url, requestData);
  }

  getSession() {
    return this.userSubject.asObservable();
  }

  removeSession() {
    this.signout();
    this.userSubject.next(null);
    this._route.navigate(['auth/login']);

  }
 
  createSession(user: any) {
    console.log("user", user);
    localStorage.setItem('user', JSON.stringify(user));
    this.userSubject.next(user);
  }
 
  
}


