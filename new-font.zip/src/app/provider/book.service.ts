import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  apiUrl:any;
  bookData:any;
  constructor(public http:HttpClient) { 
    this.apiUrl=environment.apiUrl;
  }

  addBook(reqObj: any): Observable<any> {
    return this.http.post(this.apiUrl + 'Book', reqObj);
  }
  assignbook(reqObj: any): Observable<any> {
    return this.http.post(this.apiUrl + 'Assignbook', reqObj);
  }
  patchBook(id: any, reqObj: any): Observable<any> {
    return this.http.patch(this.apiUrl + 'Book/' + id, reqObj);
  }
  patchAssignbook(id: any, reqObj: any): Observable<any> {
    return this.http.patch(this.apiUrl + 'Assignbook/' + id, reqObj);
  }

  deleteBook(id: any): Observable<any> {
    return this.http.delete(this.apiUrl + 'Book/' + id);
  }
  deleteassignbook(id: any): Observable<any> {
    return this.http.delete(this.apiUrl + 'Assignbook/' + id);
  }
  
  getBook(): Observable<any> {
    return this.http.get(this.apiUrl + 'Book');
  }
  getAssignbook(): Observable<any> {
    return this.http.get(this.apiUrl + 'Assignbook');
  }
  getAssignbookByStatus(status:any): Observable<any> {
    return this.http.get(this.apiUrl + 'assignbook/'+status);
  }
}
