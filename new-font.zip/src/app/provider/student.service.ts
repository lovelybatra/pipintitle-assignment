import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment'

@Injectable({
  providedIn: 'root'
})
export class StudentService {

 
  apiUrl:any;
  studentData:any;
  constructor(public http:HttpClient) { 
    this.apiUrl=environment.apiUrl;
  }

  addstudent(reqObj: any): Observable<any> {
    return this.http.post(this.apiUrl + 'student', reqObj);
  }
  patchstudent(id: any, reqObj: any): Observable<any> {
    return this.http.patch(this.apiUrl + 'student/' + id, reqObj);
  }

  deletestudent(id: any): Observable<any> {
    return this.http.delete(this.apiUrl + 'student/' + id);
  }
  
  getstudent(): Observable<any> {
    return this.http.get(this.apiUrl + 'student');
  }
}
