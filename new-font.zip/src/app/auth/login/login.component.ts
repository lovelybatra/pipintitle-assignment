import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../provider/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  signinForm!: FormGroup;
  loginDisable!: boolean
  response: any;
  showingError!: boolean
  constructor(private router: Router,
    private route: ActivatedRoute,
    private auth: AuthService,
    private fb: FormBuilder,) {


  }

  ngOnInit(): void {
    if (!localStorage.getItem('foo')) { 
      localStorage.setItem('foo', 'no reload') 
      location.reload() 
    } else {
      localStorage.removeItem('foo') 
    }
  
    this.showingError = false;
    this.loginDisable = false;
    this.signinForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
//_P@ssw0rd01!_
    this.response = {};
  }
  get Username() { return this.signinForm.get('email'); }
  get Password() { return this.signinForm.get('password'); }

  onLoggedin(e:any) {
    this.loginDisable = true;

    e.preventDefault();
    let requestData = {
      UserName: this.Username?.value,
      Password: this.Password?.value,
    };
    console.log(requestData);
    this.auth.login(requestData).subscribe(
      (res: any) => {
        this.response = res;
  

       this.loginDisable = false;
       if( this.response.success){
        this.auth.createSession(this.response);
        localStorage.setItem('isLoggedin', 'true');
        this.router.navigate(['/dashboard']);
 
       }
       
      },
      (err) => {
        console.log(err);
      }
    );
  }



 
}


